# FaBoLCDmini-AQM0802A-Library

This is a library for FaBo #213 LCD mini I2C Brick.

## FaBo LCD mini I2C Brick

[#213 LCD mini I2C Brick](http://fabo.io/213.html)

## AQM0802A

AQM0802A is I2C 8x2 LCD module.

### AQM0802A Datasheet

[AQM0802A Datasheet](http://akizukidenshi.com/download/ds/xiamen/AQM0802.pdf)

## Releases

- 1.0.0 Initial release.

## How to install

[Installing Additional Arduino Libraries](https://www.arduino.cc/en/Guide/Libraries)
